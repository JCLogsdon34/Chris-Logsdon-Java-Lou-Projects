var less = {
    logLevel: 4,
    errorReporting: "console",
    strictMath: true,
    strictUnits: true };
