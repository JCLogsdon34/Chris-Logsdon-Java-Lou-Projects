var less = {
    strictUnits: true,
    strictMath: true,
    logLevel: 4 };
